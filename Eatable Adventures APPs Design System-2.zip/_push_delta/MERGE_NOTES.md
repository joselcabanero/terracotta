# Delta to merge into joselcabanero/terracotta main

Copy every file in this folder to the same path in the repo (additive; nothing here overwrites existing rebrand work except the two ui_kits files, which only gate the createRoot call).

Then paste these sections into the repo's docs:

## DESIGN.md — replace section 9 with:

## 9. Charts & data visualization

Fixed hierarchy — color by **relevance**, not decoration: **Red → Orange → Burgundy → Yellow → Dark Cream → Grey (neutral) → Black (axes/text)** (`--chart-1…5`, `--chart-neutral`, `--chart-axis`). Applies to every chart type. Expressive "impact" charts (gradients in the viz) are reserved for reports/covers, never consulting decks.

**Supported types** (see `Charts Catalogue.html` and the `preview/chart-*.html` cards): KPI tiles · bar · horizontal bars · line · area · donut · stacked bars · funnel · progress-vs-target · heatmap · sunburst · timeline/Gantt · radar · scatter/bubble · waterfall · treemap · sankey.

**Rules:** Rubik everywhere; axis labels 11px `--fg3`, value labels 500 in EAV Black; hairline axes + dashed guides, no boxed plots. Max five series/segments. No 3D, shadows or full pies. Rounded bar ends / cells. The only gradients inside a chart are the single-series area fade and the heatmap ramp. Waterfall decreases are hollow grey (neutral, not "bad"); sankey flows carry the source node's rank color at ~55%; sunburst children inherit the parent hue. The yellow light point marks "today"/a milestone or the last point of the primary line.

---



## README.md — add before "### Motion":

### Charts & data visualization
Color is assigned by **relevance**, in a fixed order: **Red → Orange → Burgundy → Yellow → Dark Cream → Grey (neutral) → Black (axes/text)**. Seventeen chart types are specified in `Charts Catalogue.html` (and as `preview/chart-*` cards): KPI tiles, bar, horizontal bars, line, area, donut, stacked bars, funnel, progress-vs-target, heatmap, sunburst, timeline/Gantt, radar, scatter, waterfall, treemap, sankey. Max five series; no 3D, shadows or full pies; the only in-chart gradients are the area fade and heatmap ramp.


## README.md — file index rows to add:

| `Charts Catalogue.html` | Data-visualization catalogue — 17 chart types on the brand hierarchy, with rules. |
| `components/` | Exported React components (Button). |

## SKILL.md — add bullet:

- **Charts:** fixed hierarchy Red→Orange→Burgundy→Yellow→Dark Cream→Grey→Black, by relevance. 17 specified types in `Charts Catalogue.html`. Max five series; no 3D/shadows/full pies.

Commit: git add -A && git commit -m "Add charts catalogue, chart specimen cards, Button component, thumbnail" && git push origin main
